function AnimalShow() {
  return <div>Cow!</div>;
}

export default AnimalShow;
