function AnimalShow({ type }) {
  return <div>{type}</div>;
}

export default AnimalShow;
