function App() {
  return <div>Show animal list here!</div>;
}

export default App;
